const person = {
    name: 'John',
    age: 30,
    gender: 'male',
  };

  person.name = 'Jack';
  console.log(person.name); // Jack